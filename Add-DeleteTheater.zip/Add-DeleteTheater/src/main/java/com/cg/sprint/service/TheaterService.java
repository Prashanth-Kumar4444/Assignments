package com.cg.sprint.service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.sprint.bean.Theater;
import com.cg.sprint.dao.TheaterDao;
import com.cg.sprint.exceptions.InvalidTheaterIdException;
@Service
public class TheaterService 
{
	@Autowired
	TheaterDao tdao;
	public void setTdao(TheaterDao tdao)
	{
		this.tdao=tdao;
	}
	//InsertTheater
	@Transactional
    public Theater insertTheater(Theater theater)
    {
			return tdao.save(theater);	   
    }
	@Transactional(readOnly=true)
	/*public Theater getTheater(int theaterId) throws InvalidTheaterIdException
	{
		try
		{
			return tdao.findById(theaterId).get();	
		}
		catch(Exception e)
		{
			throw new InvalidTheaterIdException("Invalid Theater id");
		}
	}*/
	public Optional<Theater> getTheater(int theaterId)
	{
		return tdao.findById(theaterId);
	}
	@Transactional(readOnly=true)
	public List<Theater> getTheater()
	{
		return tdao.findAll();
	}
    //DeleteTheater
    public String deleteTheater(int theaterId) throws InvalidTheaterIdException
    {
    	try
    	{
    		tdao.deleteById(theaterId);
        	return "Theater Deleted Successfully";
    	}
    	catch(Exception e)
    	{
    		throw new InvalidTheaterIdException("Invalid TheaterId");
    	}
    }
}