package com.cg.sprint.exceptions;

@SuppressWarnings("serial")
public class InvalidTheaterDetailsException extends Exception
{
	public InvalidTheaterDetailsException()
	{
		super();
	}
	public InvalidTheaterDetailsException(String message)
	{
		super(message);
	}

}
