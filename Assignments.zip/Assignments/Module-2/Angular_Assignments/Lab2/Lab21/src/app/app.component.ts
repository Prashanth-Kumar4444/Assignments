
import { Component, OnInit } from '@angular/core';
import { Employee } from './app.employee';
import { empList } from './app.empList';
import { EmployeeService } from './app.empservice';
@Component({
 selector:'app-root',
 templateUrl:'./app.component.html',
 styles:['']
})
export class AppComponent implements OnInit
{
  title(title: any) {
    throw new Error("Method not implemented.");
  }
   emp:Employee[];
   empData:Employee=new Employee(null," ",null," ");
   index:number=null;
   public constructor(private employeeService:EmployeeService)
   {
   }
   ngOnInit()
   {
     this.emp=this.employeeService.getAllEmployees();
   }
   public delEmp(e:Employee):void
   {
      let index= this.emp.indexOf(e);
      this.emp.splice(index,1);
      console.log(index+" is deleted");
   }
   public modEmp(e:Employee):void
   {
     this.index=this.emp.indexOf(e);
     this.empData.empid=e.empid;
     this.empData.ename=e.ename;
     this.empData.salary=e.salary;
     this.empData.department=e.department;
   }
   public doModEmp(empid:number,ename:string,salary:number,department:string)
   {
     this.emp[this.index].empid=empid;
     this.emp[this.index].ename=ename;
     this.emp[this.index].salary=salary; 
     this.emp[this.index].department=department;
     alert();
     console.log("Employee Record Updated Successfully"); 
   }
   public addEmp(empid:number,ename:string,salary:number,department:string)
   {
     this.emp.push(new Employee(empid,ename,salary,department));
     alert();
     console.log("Employee Record Added Successfully");
   }
  
}

