import { Employee } from './app.employee';
export const empList:Employee[]=[
                                  new Employee(101,"Osama",52000,"Taliban"), 
                                  new Employee(102,"Bin",25000,"Taliban"),
                                  new Employee(103,"Laden",63000,"Taliban"),
                                  new Employee(104,"Dawood",56000,"ISI"),
                                  new Employee(105,"Ibrahim",100000,"ISI")
                                  ];