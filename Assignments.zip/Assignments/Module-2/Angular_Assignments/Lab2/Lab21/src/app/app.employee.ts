export class Employee
{
  empid:number;
  ename:string;
  salary:number;
  department:string;
  public constructor(empid:number,ename:string,salary:number,department:string)
  {
    this.empid=empid;
    this.ename=ename;
    this.salary=salary;
    this.department=department;
  }
}