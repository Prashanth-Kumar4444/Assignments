import { Employee } from './app.employee';
import { empList } from './app.empList';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService
{
   public getAllEmployees():Employee[]
   {
     return empList;
   }  
}