import { Component,OnInit } from '@angular/core';
import { EmployeeService } from './app.empservice';
import { Employee } from './app.employee';
@Component({
  selector:'app-root',
  templateUrl:'./app.component.html'
})
export class AppComponent implements OnInit
{
  title(title: any) {
    throw new Error("Method not implemented.");
  }
  empData:Employee[];
  public constructor(private empService:EmployeeService)
  {
  }
  ngOnInit()
  {
     this.empData=this.empService.getAllEmployees();
  }
  public sortById():void
  {
    let x=1;
    console.log(this.empData.length);
    for(let i=0;i<this.empData.length-1;i++)
    {
      for(let j=i+1;j<this.empData.length;j++)
      {
        if(this.empData[i].empid>this.empData[j].empid)
        {
          let tempEmployee=this.empData[i];
          this.empData[i]=this.empData[j];
          this.empData[j]=tempEmployee;
        }
      }
    }
  }
  public sortBySalary():void
  {
    let x=1;
    console.log(this.empData.length);
    for(let i=0;i<this.empData.length-1;i++)
    {
      for(let j=i+1;j<this.empData.length;j++)
      {
        if(this.empData[i].salary>this.empData[j].salary)
        {
          let tempEmployee=this.empData[i];
          this.empData[i]=this.empData[j];
          this.empData[j]=tempEmployee;
        }
      }
    }
  }
  public sortByName():void
  {
    let x=1;
    console.log(this.empData.length);
    for(let i=0;i<this.empData.length-1;i++)
    {
      for(let j=i+1;j<this.empData.length;j++)
      {
        if(this.empData[i].ename>this.empData[j].ename)
        {
          let tempEmployee=this.empData[i];
          this.empData[i]=this.empData[j];
          this.empData[j]=tempEmployee;
        }
      }
    }
  }
  public sortByDepartment():void
  {
    let x=1;
    console.log(this.empData.length);
    for(let i=0;i<this.empData.length-1;i++)
    {
      for(let j=i+1;j<this.empData.length;j++)
      {
        if(this.empData[i].department>this.empData[j].department)
        {
          let tempEmployee=this.empData[i];
          this.empData[i]=this.empData[j];
          this.empData[j]=tempEmployee;
        }
      }
    }
  }
}
