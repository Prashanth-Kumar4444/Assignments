import { Component } from '@angular/core';
@Component({
   selector:'first-element',
   templateUrl:'./app.mycomponent.html',
   styles:['']
})
export class MyComponent
{
   

}