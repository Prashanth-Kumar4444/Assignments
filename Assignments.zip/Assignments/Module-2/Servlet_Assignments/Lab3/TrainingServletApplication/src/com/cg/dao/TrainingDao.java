package com.cg.anurag.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Training;

public interface TrainingDao {
	public ArrayList<Training> getTraining();

}
